/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package analysetableaux;

/**
 *
 * @author nicho
 */
public class AnalyseTableauEntiers {

    static void fct0(int[] t) {
        for (int i = 0; i < t.length; i++) {
            t[i] = (int) (Math.random() * 100);
        }
    }

    static void fct1(int[] t) {
        for (int i = 0; i < t.length; i++) {
            System.out.println("t[" + i + "]=" + t[i]);
        }
    }

    static int fct2(int[] t) {
        int s = 0;
        for (int i = 0; i < t.length; i++) {
            s += t[i];
        }
        return s;
    }
    
    static int fct3 (int[] t) {
        int m = t[0];
        for (int i = 1; i < t.length; i++) {
            m = t[i] < m ? m : t[i];
        }
        return m;
    }

}
