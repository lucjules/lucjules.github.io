/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package analysetableaux;

import static analysetableaux.AnalyseTableauEntiers.fct0;

/**
 *
 * @author nicho
 */
public class AnalyseTableaux {
    final static int TAILLE_TAB = 10;
    static int tab[]= new int [TAILLE_TAB];
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        fct0();
    }
    
    public static void fct0(){
        AnalyseTableauEntiers.fct0(tab);                
    }
    
}
