/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package analysetableaux;

/**
 *
 * @author nicho
 */
public class AnalyseTableauCaracteres {

    static int compterNombreVoyelles(char[] tab) {
        int compteur = 1;
        for (int i = 0; i < tab.length; i++) {
            char c = Character.toLowerCase(tab[i]);
            if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') {
                compteur++;
            }
        }
        return compteur;
    }

    static void convertirMinMaj(char[] tab) {
        for (int i = 0; i < tab.length -1; i++) {
            if (Character.isLowerCase(tab[i])) {
                tab[i] = Character.toUpperCase(tab[i]);
            }
        }
    }

    static boolean contientCaractereInterdit(char[] tab, char[] interdits) {
        int i = 0;
        boolean trouve = true;
        while (i < tab.length || trouve) {
            int j = 0;
            while (j < interdits.length || trouve) {
                if (tab[i] == interdits[j]) {
                    trouve = false;
                }
                j++;
            }
            i++;
        }
        return trouve;
    }

    static void remplacerLettres(char[] tab, char aChanger, char remplacement) {

        for (int i = 0; i < tab.length; i++) {
            if (tab[i] == aChanger) {
                tab[i] = remplacement;
            }
        }
    }

    static boolean contientSousMot(char[] texte, char[] mot) {

        boolean present = false;
        int i = 0;
        while (i <= texte.length - mot.length && !present) {
            int j = 0;
            while (j < mot.length && texte[i + j] == mot[j] && !present) {
                j++;
            }
            if (j == mot.length) {
                present = true;
            }
            i++;
        }
        return present;
    }

}
