/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package analysetableaux;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author nicho
 */
public class AnalyseTableauCaracteresTest {

    @Test
    public void testConvertirMinMaj() {
        char[] tab = {'a', 'b', 'c'};
        AnalyseTableauCaracteres.convertirMinMaj(tab);
        assertArrayEquals(new char[]{'A', 'B', 'C'}, tab);

        char[] tab2 = {'a', '!', 'c'};
        AnalyseTableauCaracteres.convertirMinMaj(tab2);
        assertArrayEquals(new char[]{'A', '!', 'C'}, tab2);

        char[] tab3 = {'à', '!', 'd'};
        AnalyseTableauCaracteres.convertirMinMaj(tab3);
        assertArrayEquals(new char[]{'À', '!', 'D'}, tab3);

        char[] tab4 = {'À', '!', 'D'};
        AnalyseTableauCaracteres.convertirMinMaj(tab4);
        assertArrayEquals(new char[]{'À', '!', 'D'}, tab4);

        char[] tab5 = {'À', '!', 'd'};
        AnalyseTableauCaracteres.convertirMinMaj(tab5);
        assertArrayEquals(new char[]{'À', '!', 'D'}, tab5);

        char[] tab6 = {'d'};
        AnalyseTableauCaracteres.convertirMinMaj(tab6);
        assertArrayEquals(new char[]{'D'}, tab6);

    }

    @Test
    public void testCompterNombreVoyelles() {
        char[] tab1 = {'a', 'e', 'i', 'o', 'u', 'y'};
        assertEquals(6, AnalyseTableauCaracteres.compterNombreVoyelles(tab1));

        char[] tab2 = {'A', 'E', 'I', 'O', 'U', 'Y'};
        assertEquals(6, AnalyseTableauCaracteres.compterNombreVoyelles(tab2));

        char[] tab3 = {'b', 'c', 'd', 'f', 'g'};
        assertEquals(0, AnalyseTableauCaracteres.compterNombreVoyelles(tab3));

        char[] tab4 = {'H', 'e', 'l', 'l', 'o'};
        assertEquals(2, AnalyseTableauCaracteres.compterNombreVoyelles(tab4));

        char[] tab5 = {'B', 'J', 'J', 'F', 'R', 'y'};
        assertEquals(1, AnalyseTableauCaracteres.compterNombreVoyelles(tab5));

        char[] tab6 = {'a'};
        assertEquals(1, AnalyseTableauCaracteres.compterNombreVoyelles(tab6));

        char[] tab7 = {'A'};
        assertEquals(1, AnalyseTableauCaracteres.compterNombreVoyelles(tab7));

        char[] tab8 = {'!'};
        assertEquals(0, AnalyseTableauCaracteres.compterNombreVoyelles(tab8));
    }

    @Test
    public void testContientCaractereInterdit() {
        char[] tab1 = {'a', 'b', 'c'};
        char[] interdits1 = {'x', 'y', 'b'};
        assertTrue(AnalyseTableauCaracteres.contientCaractereInterdit(tab1, interdits1));

        char[] tab2 = {'a', 'b', 'c'};
        char[] interdits2 = {'x', 'y', 'z'};
        assertFalse(AnalyseTableauCaracteres.contientCaractereInterdit(tab2, interdits2));

        char[] tab3 = {};
        char[] interdits3 = {'a', 'b'};
        assertFalse(AnalyseTableauCaracteres.contientCaractereInterdit(tab3, interdits3));

        char[] tab4 = {'a', 'b', 'c'};
        char[] interdits4 = {};
        assertFalse(AnalyseTableauCaracteres.contientCaractereInterdit(tab4, interdits4));

        char[] tab5 = {'x', 'y', 'z'};
        char[] interdits5 = {'z'};
        assertTrue(AnalyseTableauCaracteres.contientCaractereInterdit(tab5, interdits5));

        char[] tab6 = {'!', '@', '#'};
        char[] interdits6 = {'!', '@', '#'};
        assertTrue(AnalyseTableauCaracteres.contientCaractereInterdit(tab6, interdits6));

        char[] tab7 = {'%'};
        char[] interdits7 = {'%'};
        assertTrue(AnalyseTableauCaracteres.contientCaractereInterdit(tab7, interdits7));

        char[] tab8 = {'%'};
        char[] interdits8 = {'&'};
        assertFalse(AnalyseTableauCaracteres.contientCaractereInterdit(tab8, interdits8));
    }

    @Test
    public void testRemplacerLettres() {

        char[] tab1 = {'a', 'b', 'c'};
        AnalyseTableauCaracteres.remplacerLettres(tab1, 'b', 'x');
        assertArrayEquals(new char[]{'a', 'x', 'c'}, tab1);

        char[] tab2 = {'a', 'b', 'b', 'c'};
        AnalyseTableauCaracteres.remplacerLettres(tab2, 'b', 'z');
        assertArrayEquals(new char[]{'a', 'z', 'z', 'c'}, tab1);

        char[] tab3 = {'a', 'b', 'c'};
        AnalyseTableauCaracteres.remplacerLettres(tab3, 'x', 'y');
        assertArrayEquals(new char[]{'a', 'b', 'c'}, tab3);

        char[] tab4 = {'a', 'b', 'c'};
        AnalyseTableauCaracteres.remplacerLettres(tab4, 'b', 'b');
        assertArrayEquals(new char[]{'a', 'b', 'b'}, tab4);

        char[] tab5 = {};
        AnalyseTableauCaracteres.remplacerLettres(tab5, 'a', 'b');
        assertArrayEquals(new char[]{}, tab5);

        char[] tab6 = {'x', 'x', 'x'};
        AnalyseTableauCaracteres.remplacerLettres(tab6, 'x', 'y');
        assertArrayEquals(new char[]{'y', 'y', 'y'}, tab6);

        char[] tab7 = {'#', '@', '#'};
        AnalyseTableauCaracteres.remplacerLettres(tab7, '#', '*');
        assertArrayEquals(new char[]{'*', '@', '*'}, tab7);

        char[] tab8 = {'é', 'a', 'é'};
        AnalyseTableauCaracteres.remplacerLettres(tab8, 'é', 'e');
        assertArrayEquals(new char[]{'e', 'a', 'e'}, tab8);
    }

    @Test
    public void testContientSousMot() {

        char[] texte1 = {'b', 'o', 'n', 'j', 'o', 'u', 'r'};
        char[] mot1 = {'b', 'o', 'n'};
        assertTrue(AnalyseTableauCaracteres.contientSousMot(texte1, mot1));

        char[] texte2 = {'s', 'a', 'l', 'u', 't'};
        char[] mot2 = {'l', 'u'};
        assertTrue(AnalyseTableauCaracteres.contientSousMot(texte2, mot2));

        char[] texte3 = {'a', 'b', 'c', 'd', 'e'};
        char[] mot3 = {'d', 'e'};
        assertTrue(AnalyseTableauCaracteres.contientSousMot(texte3, mot3));

        char[] texte4 = {'a', 'b', 'c'};
        char[] mot4 = {'x', 'y'};
        assertFalse(AnalyseTableauCaracteres.contientSousMot(texte4, mot4));

        char[] texte5 = {'a', 'b', 'c'};
        char[] mot5 = {};
        assertFalse(AnalyseTableauCaracteres.contientSousMot(texte5, mot5));

        char[] texte6 = {'a', 'b'};
        char[] mot6 = {'a', 'b', 'c'};
        assertFalse(AnalyseTableauCaracteres.contientSousMot(texte6, mot6));

        char[] texte7 = {'o', 'k'};
        char[] mot7 = {'o', 'k'};
        assertTrue(AnalyseTableauCaracteres.contientSousMot(texte7, mot7));

        char[] texte8 = {};
        char[] mot8 = {'a'};
        assertFalse(AnalyseTableauCaracteres.contientSousMot(texte8, mot8));

        char[] texte9 = {'é', 'l', 'è', 'v', 'e'};
        char[] mot9 = {'l', 'è', 'v'};
        assertTrue(AnalyseTableauCaracteres.contientSousMot(texte9, mot9));

        char[] texte10 = {'é', 'l', 'è', 'v', 'e'};
        char[] mot10 = {'e', 'l'};
        assertFalse(AnalyseTableauCaracteres.contientSousMot(texte10, mot10));

        char[] texte11 = {'a', 'b', 'c', 'd'};
        char[] mot11 = {'b', 'd'};
        assertFalse(AnalyseTableauCaracteres.contientSousMot(texte11, mot11));
    }
}
