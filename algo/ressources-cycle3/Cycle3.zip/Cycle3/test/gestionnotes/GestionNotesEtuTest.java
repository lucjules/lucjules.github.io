package gestionnotes;

/**
 * Tests unitaires de la classe GestionNotesEtu.
 */
public class GestionNotesEtuTest {
    
}
