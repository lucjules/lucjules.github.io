package gestionnotes;

/**
 * Tests unitaires de la classe GestionNotesDDE.
 */
public class GestionNotesDDE {
    
}
