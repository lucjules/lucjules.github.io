package gestionnotes;

/**
 * Gestion des notes, partie DDE.
 */
class GestionNotesDDE {
    
}
