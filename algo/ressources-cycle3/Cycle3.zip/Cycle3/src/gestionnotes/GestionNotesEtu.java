package gestionnotes;

/**
 * Gestion des notes, partie étudiants.
 */
class GestionNotesEtu {
    
}
