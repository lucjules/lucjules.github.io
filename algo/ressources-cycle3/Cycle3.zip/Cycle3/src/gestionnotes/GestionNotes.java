package gestionnotes;

/**
 * Gestion des notes (étudiant et DDE).
 */
class GestionNotes {

    public static void main(String[] args) {
    }
}
